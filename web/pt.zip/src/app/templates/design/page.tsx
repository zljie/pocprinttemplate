"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import TinyEditor from "@/components/TinyEditor";

declare global { interface Window { Handlebars?: any } }

function extractContent(html: string) {
  const styleMatch = html.match(/<style[^>]*>([\s\S]*?)<\/style>/i);
  const styles = styleMatch ? styleMatch[1] : "";
  const bodyMatch = html.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
  const body = bodyMatch ? bodyMatch[1] : html;
  const combined = (styles ? `<style>${styles}</style>\n` : "") + body;
  return combined;
}

export default function DesignPage() {
  const [initial, setInitial] = useState<string>("正在加载模板...");
  const [data, setData] = useState<any>(null);
  const [previewHtml, setPreviewHtml] = useState<string>("");
  const [api, setApi] = useState<{ getContent: () => string; setContent: (html: string) => void } | null>(null);

  useEffect(() => {
    (async () => {
      const [tplRes, dataRes] = await Promise.all([
        fetch("/cases/arrival-notice/template.html"),
        fetch("/cases/arrival-notice/data.json"),
      ]);
      const [tplHtml, json] = await Promise.all([tplRes.text(), dataRes.json()]);
      setInitial(extractContent(tplHtml));
      setData(json);
    })();
  }, []);

  const renderPreview = async () => {
    const html = api ? api.getContent() : initial;
    if (!html || !data) return;
    const mod = await import("handlebars/dist/handlebars.js").catch(() => import("handlebars"));
    const hb: any = (mod as any).default || mod;
    hb.registerHelper("formatNumber", (num: any) => {
      if (num === null || num === undefined) return "";
      const n = Number(num);
      return isNaN(n) ? String(num) : n.toLocaleString("zh-CN", { minimumFractionDigits: 3, maximumFractionDigits: 3 });
    });
    hb.registerHelper("getSpecialIdentity", (id: any) => (id ? String(id) : ""));
    const tpl = hb.compile(html);
    const out = tpl(data);
    setPreviewHtml(out);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold">模板设计（到货通知单示例）</h1>
        <Link href="/templates" className="btn btn-outline">返回列表</Link>
      </div>
      <section className="card p-4">
        <TinyEditor initial={initial} onReady={(editorApi) => setApi(editorApi)} />
        <div className="mt-3 flex justify-end gap-2">
          <button className="btn btn-outline" onClick={() => alert("已保存到本地存储")}>保存</button>
          <button className="btn btn-primary" onClick={renderPreview}>预览渲染当前内容</button>
        </div>
      </section>
      {previewHtml && (
        <section className="card p-4">
          <h2 className="font-medium mb-3">渲染预览</h2>
          <div dangerouslySetInnerHTML={{ __html: previewHtml }} />
        </section>
      )}
    </div>
  );
}
