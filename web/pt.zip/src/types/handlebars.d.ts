declare module 'handlebars/dist/handlebars.js' {
  const Handlebars: any;
  export default Handlebars;
}
